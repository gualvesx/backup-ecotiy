
const connectorConfig = {
  connector: 'default',
  service: 'ecocity-beta11-main',
  location: 'us-central1'
};
exports.connectorConfig = connectorConfig;
