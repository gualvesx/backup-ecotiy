
// This component is no longer needed as we've removed language switching functionality
// It's kept as an empty file to prevent import errors
// We will remove references to it from other files

export function LanguageSelector() {
  return null;
}
